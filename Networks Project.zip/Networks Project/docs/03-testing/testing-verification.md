# 6. Testing & Verification

**Status: Not started**

This section documents evidence that the network functions as designed.
Add screenshots and command output as each test is completed.

## 6.1 Wired Connectivity Tests

| Test | Source | Destination | Expected Result | Status |
|---|---|---|---|---|
| Ping — same floor | PC1 | AP-F1 | Success | ⬜ |
| Ping — same floor | PC2 | AP-F2 | Success | ⬜ |
| Ping — inter-VLAN | PC1 (VLAN 10) | PC2 (VLAN 20) | Success (via router) | ⬜ |
| Ping — gateway | PC1 | 192.168.49.1 | Success | ⬜ |
| Ping — gateway | PC2 | 192.168.49.65 | Success | ⬜ |

## 6.2 Wireless LAN Tests

| Test | Device | Expected Result | Status |
|---|---|---|---|
| SSID visible | Laptop0 | "TML-Floor1" visible | ⬜ |
| SSID visible | Laptop1/2 | "TML-Floor2" visible | ⬜ |
| Association | Laptop0 → AP-F1 | Connects, receives DHCP address in .0/26 range | ⬜ |
| Association | Laptop1/2 → AP-F2 | Connects, receives DHCP address in .64/26 range | ⬜ |
| Wireless-to-wired ping | Laptop0 | PC1 | Success | ⬜ |
| Cross-floor wireless ping | Laptop0 | Laptop1 (Floor 2) | Success (via router) | ⬜ |

## 6.3 DHCP Verification

| Test | Expected Result | Status |
|---|---|---|
| PC1 `ipconfig` | Address in 192.168.49.10–.60 range | ⬜ |
| PC2 `ipconfig` | Address in 192.168.49.70–.120 range | ⬜ |

## 6.4 Evidence

Add screenshots of `ping` command output, `show ip interface brief`, and
wireless client association status here as tests are completed.
