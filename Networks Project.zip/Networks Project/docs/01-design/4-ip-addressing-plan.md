# 4. IP Addressing Plan

## 4.1 Starting Block

`192.168.49.0/24` (256 addresses total), as assigned in the project brief.

## 4.2 VLSM Breakdown

### Step 1 — Reserve for future branch office

| Subnet | Range | Purpose |
|---|---|---|
| `192.168.49.0/25` | .0 – .127 (128 addresses) | Rustenburg site (current use) |
| `192.168.49.128/25` | .128 – .255 (128 addresses) | **Reserved, unused** — future branch office |

### Step 2 — Split the Rustenburg /25 into two floor subnets

| Subnet | Range | VLAN | Floor |
|---|---|---|---|
| `192.168.49.0/26` | .0 – .63 (64 addresses) | VLAN 10 | Floor 1 — Main Lab & Admin |
| `192.168.49.64/26` | .64 – .127 (64 addresses) | VLAN 20 | Floor 2 — Research Expansion (CR2) |

## 4.3 Address Assignments

### Floor 1 — `192.168.49.0/26` (usable: .1–.62, broadcast .63)

| Device | IP Address | Notes |
|---|---|---|
| Router sub-interface (Gig0/0/0.10) | 192.168.49.1 | Default gateway, Floor 1 |
| Switch1-F1 (management) | 192.168.49.2 | VLAN 10 SVI |
| AP-F1 | 192.168.49.3 | Static |
| DHCP pool | .10 – .60 | PC1, wireless clients |

### Floor 2 — `192.168.49.64/26` (usable: .65–.126, broadcast .127)

| Device | IP Address | Notes |
|---|---|---|
| Router sub-interface (Gig0/0/0.20) | 192.168.49.65 | Default gateway, Floor 2 |
| Switch2-F2 (management) | 192.168.49.66 | VLAN 20 SVI |
| AP-F2 | 192.168.49.67 | Static |
| DHCP pool | .70 – .120 | PC2, wireless clients |

## 4.4 Summary Table

| Subnet | CIDR | Usable Hosts | Assigned To |
|---|---|---|---|
| 192.168.49.0/26 | /26 | 62 | Floor 1 (VLAN 10) |
| 192.168.49.64/26 | /26 | 62 | Floor 2 (VLAN 20) |
| 192.168.49.128/25 | /25 | 126 | Reserved — future branch |

## 4.5 Justification

- **Requirement R2** (use the assigned `/24`) — fully accounted for; no
  address space is wasted.
- **Requirement R3 / Design Constraint** (branch office headroom) — a full
  unused `/25` (126 usable addresses) is reserved, sufficient for an entire
  future branch site.
- **Requirement R4 / CR2** (extra floor coverage) — Floor 2 has its own
  subnet, gateway, and DHCP pool, cleanly separated from Floor 1.
- **Efficiency** — no subnet is oversized relative to expected device counts;
  DHCP pools leave headroom for growth on each floor without encroaching on
  the branch reserve.
