# 2. Physical Topology

## 2.1 Overview

The physical topology reflects a router-core-distribution layout across two
floors of the client's building. Floor 1 is the existing main laboratory and
admin area; Floor 2 is the additional area taken over under **CR2**.

See diagram: [diagrams/physical-topology.svg](../diagrams/physical-topology.svg)

## 2.2 Device List

| Device | Model | Role |
|---|---|---|
| Main-Router | Cisco ISR 4321 / 2911 | Gateway, inter-VLAN routing |
| Core | Cisco 2960-24TT | Distribution switch, trunk aggregation |
| Switch1-F1 | Cisco 2960-24TT | Floor 1 access switch |
| Switch2-F2 | Cisco 2960-24TT | Floor 2 access switch (CR2) |
| AP-F1 | AccessPoint-PT | Floor 1 wireless coverage |
| AP-F2 | AccessPoint-PT | Floor 2 wireless coverage (CR2) |
| PC1 | PC-PT | Floor 1 wired workstation |
| PC2 | PC-PT | Floor 2 wired workstation |
| Laptop0–2 | Laptop-PT | Wireless clients (Floor 1 and Floor 2) |

## 2.3 Cabling and Port Assignments

| Link | Interface (Router/Switch A) | Interface (Switch/Device B) | Cable Type |
|---|---|---|---|
| Main-Router ↔ Core | Gig0/0/0 | Fa0/1 | Copper straight-through |
| Core ↔ Switch1-F1 | (Core Fa port — confirm exact port) | Fa0/1 | Copper straight-through |
| Core ↔ Switch2-F2 | (Core Fa port — confirm exact port) | Fa0/1 | Copper straight-through |
| Switch1-F1 ↔ AP-F1 | Access port | — | Copper straight-through |
| Switch1-F1 ↔ PC1 | Access port | — | Copper straight-through |
| Switch2-F2 ↔ AP-F2 | Access port | — | Copper straight-through |
| Switch2-F2 ↔ PC2 | Access port | — | Copper straight-through |

> **Note:** Exact Core-switch Fa port numbers for Switch1-F1 and Switch2-F2 to
> be confirmed and filled in once trunk configuration is finalised (see
> [3-logical-topology.md](3-logical-topology.md)).

## 2.4 Design Rationale

- A **core switch** sits between the router and the two floor switches,
  allowing a single router uplink to serve both floors via trunked links
  (see Section 3).
- Each floor has its **own switch and Access Point**, directly satisfying
  CR2 — the additional floor is not sharing Floor 1's hardware, but has
  independent switching and wireless coverage.
- The design intentionally avoids redundancy (e.g., dual core switches,
  redundant links) as this is outside the scope of a **Foundational**
  difficulty classification.
