# 3. Logical Topology

**Status: In progress**

## 3.1 VLAN Design

| VLAN ID | Name | Purpose | Assigned Switch |
|---|---|---|---|
| 10 | LAB-ADMIN | Floor 1 — main laboratory & admin | Switch1-F1 |
| 20 | RESEARCH-EXP | Floor 2 — research expansion (CR2) | Switch2-F2 |

VLANs are used to logically separate traffic between the two floors,
reflecting the client's research-industry need for departmental separation
(see [1-client-requirements.md, Section 1.7](1-client-requirements.md#17-design-implications)).

## 3.2 Trunking

| Link | Trunk Status | VLANs Carried |
|---|---|---|
| Main-Router ↔ Core | Trunk (router sub-interfaces) | 10, 20 |
| Core ↔ Switch1-F1 | Trunk | 10 |
| Core ↔ Switch2-F2 | Trunk | 20 |

## 3.3 Inter-VLAN Routing (Router-on-a-Stick)

The Main-Router uses sub-interfaces on Gig0/0/0 to route between VLAN 10 and
VLAN 20:

```
interface Gig0/0/0.10
 encapsulation dot1Q 10
 ip address 192.168.49.1 255.255.255.192

interface Gig0/0/0.20
 encapsulation dot1Q 20
 ip address 192.168.49.65 255.255.255.192
```

(Full configuration to be added to [../02-implementation/configurations.md](../02-implementation/configurations.md)
once implemented and verified in Packet Tracer.)

## 3.4 Wireless LAN Configuration

| AP | SSID | VLAN | Security |
|---|---|---|---|
| AP-F1 | TML-Floor1 | 10 | WPA2 (to be configured) |
| AP-F2 | TML-Floor2 | 20 | WPA2 (to be configured) |

**Pending:** SSID and security configuration, wireless client association
testing (see [../03-testing/testing-verification.md](../03-testing/testing-verification.md)).
