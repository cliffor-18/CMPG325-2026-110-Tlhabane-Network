# 1. Client Requirements

**Project:** CMPG325-2026-110 | **Version:** 1.0 | **Author:** Mo

## 1.1 Client Information

| Item | Requirement |
|---|---|
| **Project ID** | CMPG325-2026-110 |
| **Client ID** | CLI-110 |
| **Organisation** | Tlhabane Materials Testing Laboratory |
| **Location** | Rustenburg |
| **Industry** | Research |
| **Addressing Block** | `192.168.49.0/24` |
| **Networking Challenge** | Wireless LAN (AP integration and coverage) |
| **Difficulty Classification** | Foundational |
| **Change Request** | CR2 – The client takes over an additional floor/area of the building and needs coverage there |
| **Design Constraint** | A branch office may be opened within 18 months, so the addressing plan must allow for it |

## 1.2 Network Requirements

The proposed network must:

1. Provide appropriate **network connectivity and network services** for the assigned client scenario.
2. Use **Cisco Packet Tracer** for network implementation and simulation.
3. Use `192.168.49.0/24` as the basis of the IP addressing plan.
4. Include an appropriate network topology and device arrangement.
5. Configure the necessary **routers, switches, end devices, Wireless Access Points, and other required nodes**.
6. Provide successful data exchange between the appropriate network nodes.
7. Provide and demonstrate a functional **Wireless LAN**.
8. Integrate the Wireless Access Point(s) into the client's network.
9. Provide wireless coverage for the **additional floor/area specified in CR2**.
10. Allow for possible **future branch-office expansion within 18 months** through an appropriate addressing plan (see [4-ip-addressing-plan.md](4-ip-addressing-plan.md)).
11. Test and verify that the completed network operates successfully.
12. Document significant design decisions and evidence of the work in **GitHub**.

## 1.3 Networking Challenge

The assigned networking challenge is:

> **Wireless LAN (AP integration and coverage)**

The solution must configure, verify, and demonstrate the Wireless LAN within the client's network and be able to explain **what was configured, why it was appropriate, and how it was verified** (see [3-logical-topology.md](3-logical-topology.md)).

## 1.4 Change Request – CR2

The client has taken over an **additional floor/area of the building** and requires network coverage there. The final network design must accommodate this change and demonstrate that the additional area has the required wireless coverage (see [2-physical-topology.md](2-physical-topology.md) and [3-logical-topology.md](3-logical-topology.md)).

## 1.5 Future Expansion Requirement

A branch office **may be opened within 18 months**. Therefore, the IP addressing plan must be designed so that sufficient address space remains available for the future branch office rather than allocating the entire `192.168.49.0/24` network to the current site (see [4-ip-addressing-plan.md](4-ip-addressing-plan.md)).

## 1.6 Scope Boundaries

This solution must remain specific to the assigned client scenario (Tlhabane Materials Testing Laboratory) and must not be substituted with another scenario. No additional scope beyond CR2 has been introduced. Given the **Foundational** difficulty classification, the design is scaled proportionately — no dynamic routing protocols, redundancy, or advanced security features have been added beyond what is required to satisfy the stated requirements.

## 1.7 Design Implications

This section interprets the client requirements above into concrete design decisions carried forward into later sections.

| Requirement Driver | Implication | Addressed In |
|---|---|---|
| Research industry client | Research organisations commonly separate departmental traffic for reliability and clarity; the network is therefore logically segmented by floor using VLANs rather than left as a single flat broadcast domain. | [3-logical-topology.md](3-logical-topology.md) |
| CR2 – additional floor | A physically distinct floor requires its own switch and Access Point rather than extending Floor 1's existing hardware, so that coverage and traffic for the new area can be managed independently. | [2-physical-topology.md](2-physical-topology.md) |
| Branch office within 18 months | The `/24` block cannot be fully consumed by the current site. Half the address space is reserved, unused, for the future branch, avoiding a costly re-addressing exercise later. | [4-ip-addressing-plan.md](4-ip-addressing-plan.md) |
| Foundational difficulty | Design choices favour simplicity and reliability (static routing, a single core switch, no redundancy) over complexity that the assigned difficulty tier does not require. | [02](2-physical-topology.md)–[04](4-ip-addressing-plan.md) |

**Source:** Computer Networks Individual Project Brief, CMPG325-2026-110.
