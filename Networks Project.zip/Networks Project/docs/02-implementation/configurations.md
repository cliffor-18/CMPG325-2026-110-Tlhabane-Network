# 5. Device Configurations

**Status: In progress**

This section will contain the full running-configuration output (`show
running-config`) for each device once implementation is complete. Paste each
device's config into its own subsection below, and also save a copy of each
as a `.txt` file in [../configs/](../configs/) for evidence.

## 5.1 Main-Router

```
(paste `show running-config` output here once configured)
```

## 5.2 Core Switch

```
(paste `show running-config` output here once configured)
```

## 5.3 Switch1-F1

```
(paste `show running-config` output here once configured)
```

## 5.4 Switch2-F2

```
(paste `show running-config` output here once configured)
```

## 5.5 AP-F1 / AP-F2

```
(paste SSID/security config screenshots or exported settings here)
```
