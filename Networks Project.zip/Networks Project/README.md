# CMPG325 Individual Project — Tlhabane Materials Testing Laboratory

**Project ID:** CMPG325-2026-110
**Client ID:** CLI-110
**Assigned Networking Challenge:** Wireless LAN (AP integration and coverage)
**Difficulty Classification:** Foundational

## Overview

This repository documents the design, implementation, and testing of a computer
network for **Tlhabane Materials Testing Laboratory** (Rustenburg), built to
satisfy the requirements of the CMPG325 Individual Project brief.

The network integrates a Wireless LAN across two floors — the original main
floor and an additional floor taken over under **Change Request CR2** — while
reserving IP address space for a possible future branch office.

## Repository Structure

Folders are organised to mirror the project's grading criteria, so each
rubric item maps directly to a section of this repo.

```
tml-network-project/
├── README.md
│
├── docs/
│   ├── 01-design/                         -> Rubric 1: Client Requirements & Network Design (15%)
│   │   ├── 1-client-requirements.md
│   │   ├── 2-physical-topology.md
│   │   ├── 3-logical-topology.md
│   │   └── 4-ip-addressing-plan.md
│   │
│   ├── 02-implementation/                 -> Rubric 2: Packet Tracer Implementation (35%)
│   │   └── configurations.md
│   │
│   └── 03-testing/                        -> Rubric 2 & 3: Functionality + WLAN verification
│       └── testing-verification.md
│
├── diagrams/
│   └── physical-topology.svg
│
├── screenshots/                           -> Evidence referenced from docs above
│   ├── physical-topology/
│   ├── wireless/
│   └── testing/
│
├── configs/                               -> Raw exported `show running-config` .txt files
│
├── packet-tracer/                         -> Final .pkt file
│
└── video/                                 -> Rubric 5: Video Demonstration (15%)
```

## Navigation

| Section | Link |
|---|---|
| Client Requirements | [docs/01-design/1-client-requirements.md](docs/01-design/1-client-requirements.md) |
| Physical Topology | [docs/01-design/2-physical-topology.md](docs/01-design/2-physical-topology.md) |
| Logical Topology | [docs/01-design/3-logical-topology.md](docs/01-design/3-logical-topology.md) |
| IP Addressing Plan | [docs/01-design/4-ip-addressing-plan.md](docs/01-design/4-ip-addressing-plan.md) |
| Configurations | [docs/02-implementation/configurations.md](docs/02-implementation/configurations.md) |
| Testing & Verification | [docs/03-testing/testing-verification.md](docs/03-testing/testing-verification.md) |

## Status (against rubric)

| Rubric Criterion | Weight | Status |
|---|---|---|
| 1. Client Requirements & Network Design | 15% | Complete |
| 2. Packet Tracer Implementation & Functionality | 35% | In progress (physical topology built, VLAN/trunk config pending) |
| 3. Assigned Networking Feature (WLAN) | 20% | Not started |
| 4. GitHub Portfolio of Evidence | 15% | In progress (this repo) |
| 5. Video Demonstration & Technical Defence | 15% | Not started |

## Author

Mo — North-West University, CMPG325
